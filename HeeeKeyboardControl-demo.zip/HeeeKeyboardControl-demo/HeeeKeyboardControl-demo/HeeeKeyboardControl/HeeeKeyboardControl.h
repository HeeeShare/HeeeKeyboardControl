//
//  HeeeKeyboardControl.h
//  HeeeKeyboardControl
//
//  Created by hgy on 2018/7/16.
//  Copyright © 2018年 hgy. All rights reserved.
//

#import <UIKit/UIKit.h>
@class HeeeKeyboardControl;

@protocol HeeeKeyboardControlDelegate <NSObject>
@optional
- (void)keyboardControl:(HeeeKeyboardControl *)keyboardControl willSelectInputView:(UIView *)inputView;
- (void)keyboardControl:(HeeeKeyboardControl *)keyboardControl pressDoneButtonWithInputView:(UIView *)inputView;

@end

@interface HeeeKeyboardControl : NSObject
@property (nonatomic,assign) CGFloat basicGap;//inputView距离键盘的基础高度
@property (nonatomic,strong) UIColor *color;
@property (nonatomic,assign) BOOL isEnStyle;

/**
 生成键盘控制的类方法
 
 @param inputViewArr 需要传入包含所有inputView的数组
 @param inputBackView 所有inputView的载体view。让正在输入的inputView始终可见，如果为nil，就没有此功能
 @param delegate 不能为空
 @return 返回的实例可以设置中英文、颜色、代理和间距
 */
+ (HeeeKeyboardControl *)makeControlWithInputViews:(NSArray *)inputViewArr inputBackView:(UIView *)inputBackView andDelegate:(id)delegate;

@end
