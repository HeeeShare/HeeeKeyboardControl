//
//  HeeeKeyboardControl.h
//  HeeeKeyboardControl
//
//  Created by hgy on 2018/7/16.
//  Copyright © 2018年 hgy. All rights reserved.
//

#import <UIKit/UIKit.h>
@class HeeeKeyboardControl;

@protocol HeeeKeyboardControlDelegate <NSObject>
@optional
- (void)keyboardControl:(HeeeKeyboardControl *)keyboardControl willSelectInputView:(UIView *)inputView;
- (void)keyboardControl:(HeeeKeyboardControl *)keyboardControl pressDoneButtonWithInputView:(UIView *)inputView;

@end

@interface HeeeKeyboardControl : NSObject
@property (nonatomic,assign) CGFloat basicGap;//inputView距离键盘的基础高度
@property (nonatomic,strong) UIColor *color;
@property (nonatomic,assign) BOOL isEnStyle;
@property (nonatomic,  weak) id<HeeeKeyboardControlDelegate> delegate;

/**
 生成键盘控制的类方法
 
 @param inputViewArr 包含了所有inputView的数组
 @param inputBackView 所有inputView的载体view。让正在输入的inputView始终可见，如果为nil，就没有此功能
 @return 返回的实例可以设置中英文、颜色、代理和间距
 */
+ (HeeeKeyboardControl *)makeControlWithInputViews:(NSArray *)inputViewArr andInputBackView:(UIView *)inputBackView;

@end
